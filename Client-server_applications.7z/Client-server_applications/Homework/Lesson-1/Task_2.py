a = b'class'
b = b'function'
c = b'method'
my_list = [a,b,c,]
for el in my_list:
    print(el)
    print(type(el))
    print(len(el))