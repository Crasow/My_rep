VAR_1 = 'разработка'
VAR_2 = 'сокет'
VAR_3 = 'декоратор'

STR_LIST = [VAR_1, VAR_2, VAR_3]

for el in STR_LIST:
    print(type(el))
    print(el)

print()

VAR_UNIC_1 = '\u0440\u0430\u0437\u0440\u0430\u0431\u043e\u0442\u043a\u0430'
VAR_UNIC_2 = '\u0441\u043e\u043a\u0435\u0442'
VAR_UNIC_3 = '\u0434\u0435\u043a\u043e\u0440\u0430\u0442\u043e\u0440'

UNIC_LIST = [VAR_UNIC_1, VAR_UNIC_2, VAR_UNIC_3]

for el in UNIC_LIST:
    print(type(el))
    print(el)